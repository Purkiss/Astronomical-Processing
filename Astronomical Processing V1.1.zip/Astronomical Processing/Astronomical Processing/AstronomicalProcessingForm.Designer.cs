﻿
namespace Astronomical_Processing
{
    partial class AstronomicalProcessing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ButtonSearch = new System.Windows.Forms.Button();
            this.ButtonSort = new System.Windows.Forms.Button();
            this.ButtonAddItem = new System.Windows.Forms.Button();
            this.ButtonDeleteItem = new System.Windows.Forms.Button();
            this.ButtonEditItem = new System.Windows.Forms.Button();
            this.ButtonFillData = new System.Windows.Forms.Button();
            this.TextBoxItem = new System.Windows.Forms.TextBox();
            this.ListBoxItems = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // ButtonSearch
            // 
            this.ButtonSearch.Location = new System.Drawing.Point(21, 31);
            this.ButtonSearch.Name = "ButtonSearch";
            this.ButtonSearch.Size = new System.Drawing.Size(141, 39);
            this.ButtonSearch.TabIndex = 0;
            this.ButtonSearch.Text = "Binary Search";
            this.ButtonSearch.UseVisualStyleBackColor = true;
            this.ButtonSearch.Click += new System.EventHandler(this.ButtonSearch_Click);
            // 
            // ButtonSort
            // 
            this.ButtonSort.Location = new System.Drawing.Point(184, 31);
            this.ButtonSort.Name = "ButtonSort";
            this.ButtonSort.Size = new System.Drawing.Size(141, 39);
            this.ButtonSort.TabIndex = 1;
            this.ButtonSort.Text = "Bubble Sort";
            this.ButtonSort.UseVisualStyleBackColor = true;
            this.ButtonSort.Click += new System.EventHandler(this.ButtonSort_Click);
            // 
            // ButtonAddItem
            // 
            this.ButtonAddItem.Location = new System.Drawing.Point(21, 82);
            this.ButtonAddItem.Name = "ButtonAddItem";
            this.ButtonAddItem.Size = new System.Drawing.Size(141, 39);
            this.ButtonAddItem.TabIndex = 2;
            this.ButtonAddItem.Text = "Add Item";
            this.ButtonAddItem.UseVisualStyleBackColor = true;
            this.ButtonAddItem.Click += new System.EventHandler(this.ButtonAddItem_Click);
            // 
            // ButtonDeleteItem
            // 
            this.ButtonDeleteItem.Location = new System.Drawing.Point(184, 82);
            this.ButtonDeleteItem.Name = "ButtonDeleteItem";
            this.ButtonDeleteItem.Size = new System.Drawing.Size(141, 39);
            this.ButtonDeleteItem.TabIndex = 3;
            this.ButtonDeleteItem.Text = "Delete Item";
            this.ButtonDeleteItem.UseVisualStyleBackColor = true;
            this.ButtonDeleteItem.Click += new System.EventHandler(this.ButtonDeleteItem_Click);
            // 
            // ButtonEditItem
            // 
            this.ButtonEditItem.Location = new System.Drawing.Point(21, 134);
            this.ButtonEditItem.Name = "ButtonEditItem";
            this.ButtonEditItem.Size = new System.Drawing.Size(141, 39);
            this.ButtonEditItem.TabIndex = 4;
            this.ButtonEditItem.Text = "Edit Item";
            this.ButtonEditItem.UseVisualStyleBackColor = true;
            this.ButtonEditItem.Click += new System.EventHandler(this.ButtonEditItem_Click);
            // 
            // ButtonFillData
            // 
            this.ButtonFillData.Location = new System.Drawing.Point(184, 134);
            this.ButtonFillData.Name = "ButtonFillData";
            this.ButtonFillData.Size = new System.Drawing.Size(141, 39);
            this.ButtonFillData.TabIndex = 5;
            this.ButtonFillData.Text = "Fill Data";
            this.ButtonFillData.UseVisualStyleBackColor = true;
            this.ButtonFillData.Click += new System.EventHandler(this.ButtonFillData_Click);
            // 
            // TextBoxItem
            // 
            this.TextBoxItem.Location = new System.Drawing.Point(21, 199);
            this.TextBoxItem.Name = "TextBoxItem";
            this.TextBoxItem.Size = new System.Drawing.Size(304, 20);
            this.TextBoxItem.TabIndex = 6;
            this.TextBoxItem.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxItem_KeyPress);
            // 
            // ListBoxItems
            // 
            this.ListBoxItems.FormattingEnabled = true;
            this.ListBoxItems.Location = new System.Drawing.Point(21, 237);
            this.ListBoxItems.Name = "ListBoxItems";
            this.ListBoxItems.Size = new System.Drawing.Size(304, 316);
            this.ListBoxItems.TabIndex = 7;
            this.ListBoxItems.SelectedIndexChanged += new System.EventHandler(this.ListBoxItems_SelectedIndexChanged);
            // 
            // AstronomicalProcessing
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 574);
            this.Controls.Add(this.ListBoxItems);
            this.Controls.Add(this.TextBoxItem);
            this.Controls.Add(this.ButtonFillData);
            this.Controls.Add(this.ButtonEditItem);
            this.Controls.Add(this.ButtonDeleteItem);
            this.Controls.Add(this.ButtonAddItem);
            this.Controls.Add(this.ButtonSort);
            this.Controls.Add(this.ButtonSearch);
            this.Name = "AstronomicalProcessing";
            this.Text = "Astronomical Processing";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ButtonSearch;
        private System.Windows.Forms.Button ButtonSort;
        private System.Windows.Forms.Button ButtonAddItem;
        private System.Windows.Forms.Button ButtonDeleteItem;
        private System.Windows.Forms.Button ButtonEditItem;
        private System.Windows.Forms.Button ButtonFillData;
        private System.Windows.Forms.TextBox TextBoxItem;
        private System.Windows.Forms.ListBox ListBoxItems;
    }
}

